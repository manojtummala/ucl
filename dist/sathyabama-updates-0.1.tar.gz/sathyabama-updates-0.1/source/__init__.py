from source.scl import get

if __name__ == '__main__':
    get()
